
import logica.Banda;

public class Launcher {

    private Banda myBanda;

    public Launcher() {
        myBanda = new Banda();

        myBanda.contratarMusicos();

        System.out.println("\tOrganizando Banda...");
        myBanda.afinarInstrumentos();

        System.out.println("\tTocando Banda");
        myBanda.tocarBanda();
    }

    public static void main(String[] args) {
        new Launcher();
    }

}
