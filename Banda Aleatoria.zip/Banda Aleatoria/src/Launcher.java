
import javax.swing.JOptionPane;
import logica.Banda;

public class Launcher {

    private Banda myBanda;
    private int musicosDisponibles;

    public Launcher() {
        System.out.println("\tIniciando Banda...\n");
        myBanda = new Banda();
        musicosDisponibles = (int) (Math.random() * (21));

        myBanda.setNombre(JOptionPane.showInputDialog("Ingrese un nombre para la Banda", null));

        myBanda.contratarMusicos(musicosDisponibles);

        System.out.println("\tOrganizando Banda: " + myBanda.getNombre());
        myBanda.afinarInstrumentos(myBanda.getMusicos());

        System.out.println("\tTocando Banda: " + myBanda.getNombre());
        myBanda.tocarBanda(myBanda.getMusicos());
    }

    public static void main(String[] args) {
        new Launcher();
    }

}
