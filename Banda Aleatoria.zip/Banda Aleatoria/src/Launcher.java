
import javax.swing.JOptionPane;
import logica.Banda;

public class Launcher {

    private Banda myBanda;

    public Launcher() {
        System.out.println("\tIniciando Banda...\n");
        myBanda = new Banda();

        myBanda.setNombre(JOptionPane.showInputDialog("Ingrese un nombre para la Banda", null));

        myBanda.contratarMusicos();

        System.out.println("\tAfinando Banda...");
        myBanda.afinarInstrumentos();

        System.out.println("\tTocando Banda: " + myBanda.getNombre());
        myBanda.tocarBanda();
    }

    public static void main(String[] args) {
        new Launcher();
    }

}
