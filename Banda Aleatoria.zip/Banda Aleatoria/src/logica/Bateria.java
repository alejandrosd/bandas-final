package logica;

public class Bateria implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando bateria.");
    }

    @Override
    public void ajustar() {
        System.out.println("Bateria ajustada.");
    }
}
