package logica;

public class Piano implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando piano.");
    }

    @Override
    public void ajustar() {
        System.out.println("Piano ajustado.");
    }
    
    @Override
    public void afinar() {
        System.out.println("Piano afinado.");
    }

}
