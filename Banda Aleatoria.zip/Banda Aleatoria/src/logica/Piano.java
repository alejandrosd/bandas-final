package logica;

public class Piano implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando Piano.");
    }

    @Override
    public void ajustar() {
        System.out.println("Piano ajustado.");
    }

}
