package logica;

public interface Instrumento {

    public void sonar();

    public void ajustar();
    
    public void afinar();
}
