package logica;

import java.util.ArrayList;
import java.util.List;

public class Banda {

    private String nombre;
    private List<Musico> musicos;

    public void contratarMusicos(int numMusicos) {
        musicos = new ArrayList<>();

        int aux = 1;

        for (int i = 0; i < numMusicos; i++) {
            Instrumento instrumento = determinarInstruemto(7);

            Musico musico = new Musico();

            musico.setNombre(String.valueOf(aux));
            musico.setInstrumento(instrumento);

            musicos.add(musico);

            aux++;
        }
    }

    public Instrumento determinarInstruemto(int numInstrumentos) {
        int tipo = (int) (Math.random() * (numInstrumentos));

        switch (tipo) {
            case 0:
                return new Guitarra();
            case 1:
                return new Bateria();
            case 2:
                return new Saxofon();
            case 3:
                return new Piano();
            case 4:
                return new Flauta();
            case 5:
                return new Tambor();
            case 6:
                return new Violin();
            default:
                System.err.println("¡El instrumento no está disponible!");
                return null;
        }
    }

    public void afinarInstrumentos(List<Musico> musicos) {

        for (int i = 0; i < musicos.size(); i++) {
            Musico musico = musicos.get(i);

            System.out.println("Afinando instrumento de Músico " + musicos.get(i).getNombre() + ":");

            musico.afinarInstrumento(musico.getInstrumento());

            System.out.println();
        }
    }

    public void tocarBanda(List<Musico> musicos) {
        for (int i = 0; i < musicos.size(); i++) {
            Musico musico = musicos.get(i);

            musico.tocarInstrumento(musico.getInstrumento());
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Musico> getMusicos() {
        return musicos;
    }

}
