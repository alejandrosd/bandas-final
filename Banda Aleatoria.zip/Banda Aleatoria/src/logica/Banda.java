package logica;

import java.util.ArrayList;
import java.util.List;

public class Banda {

    private String nombre;
    private List<Musico> musicos;

    public void contratarMusicos() {
        musicos = new ArrayList<>();

        int disponibles = (int) (Math.random() * (21));
        int aux = 1;

        for (int i = 0; i < disponibles; i++) {
            Musico musico = new Musico();
            musico.setNombre(String.valueOf(aux));

            musicos.add(musico);

            aux++;
        }
    }

    public Instrumento determinarInstruemto() {
        int tipo = (int) (Math.random() * (6));

        switch (tipo) {
            case 0:
                return new Guitarra();
            case 1:
                return new Bateria();
            case 2:
                return new Saxofon();
            case 3:
                return new Piano();
            case 4:
                return new Flauta();
            case 5:
                return new Tambor();
            case 6:
                return new Violin();
            default:
                System.err.println("¡El instrumento no está disponible!");
                return null;
        }
    }

    public void afinarInstrumentos() {

        for (int i = 0; i < musicos.size(); i++) {
            Instrumento instrumento = determinarInstruemto();
            Musico musico = musicos.get(i);

            System.out.println("Asignando Instrumento \nMúsico " + musicos.get(i).getNombre() + ":");

            musico.setInstrumento(instrumento);
            musico.afinarInstrumento(instrumento);

            System.out.println();
        }
    }

    public void tocarBanda() {
        for (int i = 0; i < musicos.size(); i++) {
            musicos.get(i).tocarInstrumento();
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
