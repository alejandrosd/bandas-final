package logica;

import java.util.ArrayList;
import java.util.List;

public class Banda {

    private List<Musico> musicos;

    public void contratarMusicos() {
        musicos = new ArrayList<>();

        int disponibles = (int) (Math.random() * (21));

        for (int i = 0; i < disponibles; i++) {
            musicos.add(new Musico());
        }
    }

    public Instrumento determinarInstruemto() {
        int tipo = (int) (Math.random() * (5));

        switch (tipo) {
            case 0:
                return new Guitarra();
            case 1:
                return new Bateria();
            case 2:
                return new Guitarra();
            case 3:
                return new Guitarra();
            default:
                return new Guitarra();
        }
    }

    public void afinarInstrumentos() {
        int aux = 1;

        for (int i = 0; i < musicos.size(); i++) {
            Instrumento instrumento = determinarInstruemto();
            Musico musico = musicos.get(i);

            System.out.println("Asignando Instrumento a Músico " + aux + ":");

            musico.setInstrumento(instrumento);
            musico.afinarInstrumento(instrumento);

            System.out.println();
            aux++;
        }
    }

    public void tocarBanda() {
        for (int i = 0; i < musicos.size(); i++) {
            musicos.get(i).tocarInstrumento();
        }
    }
}
