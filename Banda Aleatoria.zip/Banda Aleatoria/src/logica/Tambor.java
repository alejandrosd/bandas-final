package logica;

public class Tambor implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando tambor.");
    }

    @Override
    public void ajustar() {
        System.out.println("Tambor ajustado.");
    }
}
