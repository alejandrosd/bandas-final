package logica;

public class Violin implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando violin.");
    }

    @Override
    public void ajustar() {
        System.out.println("Violin ajustado.");
    }
}
