package logica;

public class Flauta implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando flauta.");
    }

    @Override
    public void ajustar() {
        System.out.println("Flauta ajustada.");
    }

}
