package logica;

public class Flauta implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando Flauta.");
    }

    @Override
    public void ajustar() {
        System.out.println("Flauta ajustada.");
    }

}
