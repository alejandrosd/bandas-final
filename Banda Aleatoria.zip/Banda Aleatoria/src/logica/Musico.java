package logica;

public class Musico {

    private String nombre;
    private Instrumento instrumento;

    public void afinarInstrumento(Instrumento i) {
        i.ajustar();
        i.afinar();
    }

    public void tocarInstrumento(Instrumento i) {
        i.sonar();
    }

    public void setInstrumento(Instrumento instrumento) {
        this.instrumento = instrumento;
    }

    public Instrumento getInstrumento() {
        return instrumento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
