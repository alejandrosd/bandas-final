package logica;

public class Musico {

    private Instrumento instrumento;

    public void afinarInstrumento(Instrumento instrumento) {
        instrumento.ajustar();
        System.out.println("Instrumento afinado.");
    }

    public void tocarInstrumento() {
        instrumento.sonar();
    }

    public void setInstrumento(Instrumento instrumento) {
        this.instrumento = instrumento;
    }
}
