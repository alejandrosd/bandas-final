package logica;

public class Saxofon implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando saxofon.");
    }

    @Override
    public void ajustar() {
        System.out.println("Saxofon ajustado.");
    }
    
    @Override
    public void afinar() {
        System.out.println("Saxofon afinado.");
    }

}
