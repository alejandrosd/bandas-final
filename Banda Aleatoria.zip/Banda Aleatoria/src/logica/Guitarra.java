package logica;

public class Guitarra implements Instrumento {

    @Override
    public void sonar() {
        System.out.println("Sonando guitarra.");
    }

    @Override
    public void ajustar() {
        System.out.println("Guitarra ajustada.");
    }

    @Override
    public void afinar() {
        System.out.println("Guitarra afinada.");
    }

}
